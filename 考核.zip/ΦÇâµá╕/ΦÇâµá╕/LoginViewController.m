//
//  LoginViewController.m
//  考核
//
//  Created by apple on 2021/2/22.
//

#import "LoginViewController.h"
#import "ContactViewController.h"
@interface LoginViewController ()


@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UISwitch *remPassword;
@property (weak, nonatomic) IBOutlet UISwitch *autoLogin;

@end

@implementation LoginViewController

//关闭记住密码 关闭自动登录
- (IBAction)remPassword:(UISwitch*)sender {
    if (!sender.isOn){
        [self.autoLogin setOn:NO animated:YES];
  }
}

//开启自动登录 开启记住密码
- (IBAction)autoLogin:(UISwitch*)sender {
    if (sender.isOn){
        [self.remPassword setOn:YES animated:YES];
    }
}


- (void)viewDidLoad {
    [super viewDidLoad];
  
    //监听textField
    [self.usernameField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [self.passwordField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    
    //监听登录的按钮
    [self.loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    
    //恢复开关状态
NSUserDefaults *rem = [NSUserDefaults standardUserDefaults];
self.remPassword.on = [rem boolForKey:@"remPasswordKey"];
self.autoLogin.on = [rem boolForKey:@"autoLoginKey"];

    //恢复文本框
self.usernameField.text = [rem objectForKey:@"usernameFieldKey"];
if (self.remPassword.isOn)
{
    self.passwordField.text = [rem objectForKey:@"passwordFieldKey"];
}

if(self.autoLogin.isOn)
{
    [self login];
}

    [self textChange];
}

- (void)login{
   
    if ([self.usernameField.text isEqual:@"123456"] && [self.passwordField.text isEqual:@"123456"]){
        
        //页面跳转
        [self performSegueWithIdentifier:@"LogtoContact" sender:nil];
    }else{
        [self performSegueWithIdentifier:@"Wrong" sender:nil];
    }
        
        //保存switch 账号密码的状态
        NSUserDefaults *rem = [NSUserDefaults standardUserDefaults];
        [rem setBool:self.remPassword.isOn forKey:@"remPasswordKey"];
        [rem setBool:self.autoLogin.isOn forKey:@"autoLoginKey"];
        [rem setObject:self.usernameField.text forKey:@"usernameFieldKey"];
        [rem setObject:self.passwordField.text forKey:@"passwordFieldKey"];
        [rem synchronize];//立即写入
    
}
//都要有内容登录按钮才亮
-(void)textChange{
    if(self.usernameField.text.length > 0 && self.passwordField.text.length > 0){
        self.loginButton.enabled =YES;
    }else{
        self.loginButton.enabled =NO;
    }
}
@end
