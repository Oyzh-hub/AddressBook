//
//  AddViewController.m
//  考核
//
//  Created by apple on 2021/2/23.
//

#import "AddViewController.h"
#import "Contact.h"
@interface AddViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *numberField;
@property (weak, nonatomic) IBOutlet UIButton *addButton;

@end

@implementation AddViewController

//实时监听账号密码
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.nameField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [self.numberField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [self.addButton addTarget:self action:@selector(addClick) forControlEvents:UIControlEventTouchUpInside];
}
//都要有内容添加按钮才会亮
-(void)textChange{
    if(self.nameField.text.length > 0 && self.numberField.text.length > 0){
        self.addButton.enabled =YES;
    }else{
        self.addButton.enabled =NO;
    }
}


//添加按钮点击事件
- (void)addClick{
    //判断代理方法能否响应 可以就执行
    if([self.delegate respondsToSelector:@selector(addViewController:withContact:)]){
        
        Contact * con = [[Contact alloc]init];
        con.name = self.nameField.text;
        con.number = self.numberField.text;
        [self.delegate addViewController:self withContact:con];
    }
    [self.navigationController popViewControllerAnimated:YES];
}


@end
