//
//  ContactViewController.h
//  考核
//
//  Created by apple on 2021/2/22.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface ContactViewController : UITableViewController
//顺传用
@property(nonatomic,copy) NSString *username;
@end

NS_ASSUME_NONNULL_END
