//
//  Contact.m
//  考核
//
//  Created by apple on 2021/2/23.
//

#import "Contact.h"

@implementation Contact
//归档的属性
-(void)encodeWithCoder:(NSCoder *)coder
{
    [coder encodeObject:_name forKey:@"name"];
    [coder encodeObject:_number forKey:@"number"];
}


//解档的属性
-(instancetype)initWithCoder:(NSCoder *)coder
{
    if (self = [super init]) {
        self.name = [coder decodeObjectForKey:@"name"];
        self.number = [coder  decodeObjectForKey:@"number"];
    }
    return self;
}

@end
