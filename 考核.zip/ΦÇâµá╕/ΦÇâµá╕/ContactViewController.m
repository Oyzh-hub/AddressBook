
#import "ContactViewController.h"
#import "Contact.h"
#import "AddViewController.h"
#import "EditViewController.h"
@interface ContactViewController ()<AddViewControllerDelegate,EditViewControllerDelegate>
//先创建数组存放
@property (nonatomic, strong) NSMutableArray * contacts;
@end

@implementation ContactViewController
//这是一个懒加载
-(NSMutableArray *)contacts{
    if(_contacts == nil)
    {
        _contacts = [NSMutableArray array];
    }
    return _contacts;
}

//将注销按钮添加在tableview的左上角
- (void)viewDidLoad {
    [super viewDidLoad];
    UIBarButtonItem * item = [[UIBarButtonItem alloc] initWithTitle:@"注销" style:UIBarButtonItemStyleDone target:self action:@selector(logOut)];
    self.navigationItem.leftBarButtonItem = item;
    
    //解档
     NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) [0];
     NSString * filePath = [docPath stringByAppendingPathComponent:@"contact.data"];
    self.contacts = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
}


//控制一组的行数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.contacts.count;
}


//cell的内容 并将其显示内容
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * cellid = @"contact_cell";

    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellid];

    cell.textLabel.text = [self.contacts[indexPath.row]name];
    cell.detailTextLabel.text = [self.contacts[indexPath.row]number];
    return cell;
}

//添加联系人的代理方法，逆传至主界面
- (void)addViewController:(AddViewController*)addViewController withContact:(Contact *)contact{
    //将数据放置在 contacts数组中
    [self.contacts addObject:contact];
    //刷新
    [self.tableView reloadData];
    

    //归档联系人信息
      NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES)[0];
     NSString * filePath = [docPath stringByAppendingPathComponent:@"contact.data"];
    //归档的是数组
     [NSKeyedArchiver archiveRootObject:self.contacts toFile :filePath];
    
}


//编辑联系人的代理方法
-(void)editViewController:(EditViewController *)editViewController withContact:(Contact*)contact{
    [self.tableView reloadData];
}



//storyboard路线 不论是手动型还是自动型都会调用
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    UIViewController * vc = segue.destinationViewController;
    //判断目标控制器的真实类型
    if([vc isKindOfClass:[AddViewController class]]){
        AddViewController * add =(AddViewController*)vc;//强制转换
        add.delegate = self;
    }else{
        //顺传赋值
        EditViewController * edit = (EditViewController*)vc;
        
        //设置代理
        edit.delegate = self;
        
        //获取点击 cell的位置 indexpath
        NSIndexPath * path = [self.tableView indexPathForSelectedRow];
        
        //获取模型
        Contact * con = self.contacts [path.row];
        
        //模型赋值
        edit.contact = con;
        
    }
}

    //tableView进入编辑的状态
    -(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
        //首先删除数组中的元素
        [self.contacts removeObject:self.contacts [indexPath.row]];
        [self.tableView reloadData];
    }
    
-(void)logOut{
    UIAlertController *alertcon = [UIAlertController alertControllerWithTitle:@"注销" message:@"你确定要注销吗？" preferredStyle:UIAlertControllerStyleActionSheet];

    //如果点击确定 则pop回上一个控制器中
    UIAlertAction *actionsure = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self.navigationController popViewControllerAnimated:YES];
    }];
    UIAlertAction *actioncancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {

    }];

    //将确认和取消的选项键添加在上面
    [alertcon addAction:actionsure];
    [alertcon addAction:actioncancel];
    [self presentViewController:alertcon animated:YES completion:nil];
}
@end
