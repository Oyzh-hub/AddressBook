//
//  EditViewController.m
//  考核
//
//  Created by apple on 2021/2/23.
//

#import "EditViewController.h"

@interface EditViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *numberField;
@property (weak, nonatomic) IBOutlet UIButton *saveButton;

@end
//右上角为编辑时，文本框不可改动，添加按钮隐藏
@implementation EditViewController
- (IBAction)editClick:(UIBarButtonItem*)sender {
    if ([sender.title isEqualToString:@"编辑"])
    {
        
        sender.title = @"取消";
        self.nameField.enabled =YES;
        self.numberField.enabled =YES;
        self.saveButton.hidden = NO;
    }
    else
    {
        //右上角为取消，文本可改动，添加按钮出现
        sender.title = @"编辑";
        self.nameField.enabled =NO;
        self.numberField.enabled =NO;
        self.saveButton.hidden = YES;
        
        
       //恢复到传过来的模型的数据即新数据
        self.nameField.text = self.contact.name;
        self.numberField.text = self.contact.number;
    }
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    //设置初始文本框的内容 即 传过到编辑界面的内容
    self.nameField.text = self.contact.name;
    self.numberField.text = self.contact.number;
    
    
    //监听保存按钮
    [self.saveButton addTarget:self action:@selector(saveClick) forControlEvents:UIControlEventTouchUpInside];
}

//保存的点击事件
-(void)saveClick{
    self.contact.name = self.nameField.text;
    self.contact.number = self.numberField.text;
    
    //判断代理方法是否能够响应
    if ([self.delegate respondsToSelector:@selector(editViewController:withContact:)]){
       Contact * con = [[Contact alloc] init];
        con.name = self.nameField.text;
        con.number = self.numberField.text;
        
        //如果可以响应 执行代理方法
        [self.delegate editViewController:self withContact:con];
    }
    
    
    //返回到上一个页面
    [self.navigationController popViewControllerAnimated:YES];
}
@end
