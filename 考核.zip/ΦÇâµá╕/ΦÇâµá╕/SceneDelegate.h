//
//  SceneDelegate.h
//  考核
//
//  Created by apple on 2021/2/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

